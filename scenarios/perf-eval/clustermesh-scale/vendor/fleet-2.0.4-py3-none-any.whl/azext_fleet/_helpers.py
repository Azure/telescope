# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

import errno
import os
import platform
import stat
import tempfile
import yaml
import time

from knack.log import get_logger
from knack.prompting import NoTTYException, prompt_y_n
from knack.util import CLIError
from azure.cli.command_modules.acs._roleassignments import add_role_assignment
from azure.mgmt.core.tools import parse_resource_id
from azext_fleet.constants import NETWORK_CONTRIBUTOR_ROLE_ID

from azext_fleet._client_factory import get_provider_client
from azext_fleet._client_factory import get_msi_client
from azext_fleet._client_factory import get_role_assignments_client

logger = get_logger(__name__)


def is_stdout_path(path):
    """Check if the path represents stdout."""
    return path == "-"


def print_or_merge_credentials(path, kubeconfig, overwrite_existing, context_name):
    """Merge an unencrypted kubeconfig into the file at the specified path, or print it to
    stdout if the path is "-".
    """
    # Special case for printing to stdout
    if is_stdout_path(path):
        print(kubeconfig)
        return

    # ensure that at least an empty ~/.kube/config exists
    directory = os.path.dirname(path)
    if directory and not os.path.exists(directory):
        try:
            os.makedirs(directory)
        except OSError as ex:
            if ex.errno != errno.EEXIST:
                raise
    if not os.path.exists(path):
        with os.fdopen(os.open(path, os.O_CREAT | os.O_WRONLY, 0o600), 'wt'):
            pass

    # merge the new kubeconfig into the existing one
    fd, temp_path = tempfile.mkstemp()
    additional_file = os.fdopen(fd, 'w+t')
    try:
        additional_file.write(kubeconfig)
        additional_file.flush()
        _merge_kubernetes_configurations(
            path, temp_path, overwrite_existing, context_name)
    except yaml.YAMLError as ex:
        logger.warning(
            'Failed to merge credentials to kube config file: %s', ex)
    finally:
        additional_file.close()
        os.remove(temp_path)


def _merge_kubernetes_configurations(existing_file, addition_file, replace, context_name=None):
    existing = _load_kubernetes_configuration(existing_file)
    addition = _load_kubernetes_configuration(addition_file)

    if context_name is not None:
        addition['contexts'][0]['name'] = context_name
        addition['contexts'][0]['context']['cluster'] = context_name
        addition['clusters'][0]['name'] = context_name
        addition['current-context'] = context_name

    # rename the admin context so it doesn't overwrite the user context
    for ctx in addition.get('contexts', []):
        try:
            if ctx['context']['user'].startswith('clusterAdmin'):
                admin_name = ctx['name'] + '-admin'
                addition['current-context'] = ctx['name'] = admin_name
                break
        except (KeyError, TypeError):
            continue

    if addition is None:
        raise CLIError(
            f'failed to load additional configuration from {addition_file}')

    if existing is None:
        existing = addition
    else:
        _handle_merge(existing, addition, 'clusters', replace)
        _handle_merge(existing, addition, 'users', replace)
        _handle_merge(existing, addition, 'contexts', replace)
        existing['current-context'] = addition['current-context']

    # check that ~/.kube/config is only read- and writable by its owner
    if platform.system() != "Windows" and not os.path.islink(existing_file):
        existing_file_perms = f"{stat.S_IMODE(os.lstat(existing_file).st_mode):o}"
        if not existing_file_perms.endswith("600"):
            logger.warning(
                '%s has permissions "%s".\nIt should be readable and writable only by its owner.',
                existing_file,
                existing_file_perms,
            )

    with open(existing_file, 'w+', encoding='utf-8') as stream:
        yaml.safe_dump(existing, stream, default_flow_style=False)

    current_context = addition.get('current-context', 'UNKNOWN')
    msg = f'Merged "{current_context}" as current context in {existing_file}'
    print(msg)


def _handle_merge(existing, addition, key, replace):
    if not addition[key]:
        return
    if key not in existing:
        raise CLIError(
            "No such key '{}' in existing config, please confirm whether it is a valid config file. "
            "Consider backing up the existing config file, delete it, and retry the command.".format(
                key
            )
        )
    if not existing[key]:
        existing[key] = addition[key]
        return

    for i in addition[key]:
        for j in existing[key]:
            if i['name'] == j['name']:
                if replace or i == j:
                    existing[key].remove(j)
                else:
                    msg = 'A different object named {} already exists in your kubeconfig file.\nOverwrite?'
                    overwrite = False
                    try:
                        overwrite = prompt_y_n(msg.format(i['name']))
                    except NoTTYException:
                        pass
                    if overwrite:
                        existing[key].remove(j)
                    else:
                        msg = 'A different object named {} already exists in {} in your kubeconfig file.'
                        raise CLIError(msg.format(i['name'], key))
        existing[key].append(i)


def _load_kubernetes_configuration(filename):
    try:
        with open(filename, encoding='utf-8') as stream:
            return yaml.safe_load(stream)
    except (IOError, OSError) as ex:
        if getattr(ex, 'errno', 0) == errno.ENOENT:
            raise CLIError(f'{filename} does not exist') from ex
        raise
    except (yaml.parser.ParserError, UnicodeDecodeError) as ex:
        raise CLIError(f'Error parsing {filename} ({str(ex)})') from ex


def assign_network_contributor_role_to_subnet(cmd, object_id, subnet_id):
    if not add_role_assignment(cmd, 'Network Contributor', object_id, scope=subnet_id):
        logger.warning(
            "Failed to create Network Contributor role assignment on the subnet %s.\n"
            "This role assignment is required for the managed identity to access the subnet.\n"
            "Please ensure you have sufficient permissions, or ask an administrator to run:\n"
            "az role assignment create --assignee-principal-type ServicePrincipal --assignee-object-id %s "
            "--role 'Network Contributor' --scope %s",
            subnet_id, object_id, subnet_id)
        return

    auth_client = get_role_assignments_client(cmd.cli_ctx)
    max_attempts = 3
    interval = 3
    for _ in range(max_attempts):
        if _is_assignment_present(auth_client, subnet_id, object_id):
            return
        time.sleep(interval)
    logger.warning(
        "Role assignment for Network Contributor on subnet %s was not detected after %s seconds. "
        "There may be a delay in propagation.",
        subnet_id, max_attempts * interval)


def _is_assignment_present(auth_client, subnet_id, object_id):
    filter_query = f"assignedTo('{object_id}') and atScope()"
    for assignment in auth_client.list_for_scope(subnet_id, filter=filter_query):
        if assignment.role_definition_id.lower().endswith(NETWORK_CONTRIBUTOR_ROLE_ID) and \
           assignment.scope.lower() == subnet_id.lower():
            return True
    return False


def get_msi_object_id(cmd, msi_resource_id):
    parsed = parse_resource_id(msi_resource_id)
    subscription_id = parsed['subscription']
    resource_group_name = parsed['resource_group']
    msi_name = parsed['resource_name']
    msi_client = get_msi_client(cmd.cli_ctx, subscription_id=subscription_id)
    msi = msi_client.user_assigned_identities.get(resource_name=msi_name,
                                                  resource_group_name=resource_group_name)
    return msi.principal_id


def is_rp_registered(cmd):
    resource_client = get_provider_client(cmd.cli_ctx)
    provider = resource_client.providers.get("Microsoft.ContainerService")
    return provider.registration_state == 'Registered'
